<?php 


$province = array(
    'zachodniopomorskie' => array(
        'Stwierdzone' => 23939 ,
        'Wykryte' =>     15560  ,
        '%_Wykrycia' =>  64.2
    ),
    'swietokrzyskie' => array(
        'Stwierdzone' => 11306 ,
        'Wykryte' =>     7776  ,
        '%_Wykrycia' =>  54.7
    ),
    'slaskie' => array(
        'Stwierdzone' => 63443 ,
        'Wykryte' =>     42581  ,
        '%_Wykrycia' =>  65.9
    ),
    'mazowieckie' => array(
        'Stwierdzone' => 71012 ,
        'Wykryte' =>     35280  ,
        '%_Wykrycia' =>  49.1
    ),
    'warminskomazurskie' => array(
        'Stwierdzone' =>  15757,
        'Wykryte' =>     9820  ,
        '%_Wykrycia' =>  61.4
    ),
    'pomorskie' => array(
        'Stwierdzone' => 28963 ,
        'Wykryte' =>     15913  ,
        '%_Wykrycia' =>  54.4
    ),
    'podlaskie' => array(
        'Stwierdzone' => 9722 ,
        'Wykryte' =>     5976  ,
        '%_Wykrycia' =>  60.8
    ),
    'podkarpackie' => array(
        'Stwierdzone' => 13487 ,
        'Wykryte' =>     8575  ,
        '%_Wykrycia' =>  63.0
    ),
    'opolskie' => array(
        'Stwierdzone' => 11806 ,
        'Wykryte' =>     7508  ,
        '%_Wykrycia' =>  62.6
    ),
    'lubuskie' => array(
        'Stwierdzone' => 14752 ,
        'Wykryte' =>     9404  ,
        '%_Wykrycia' =>  63.2
    ),
    'lubelskie' => array(
        'Stwierdzone' => 18716 ,
        'Wykryte' =>     19850 ,
        '%_Wykrycia' =>  61.0
    ),
    'dolnoslaskie' => array(
        'Stwierdzone' => 51982 ,
        'Wykryte' =>     28785  ,
        '%_Wykrycia' =>  54.7
    ),
    'lodzkie' => array(
        'Stwierdzone' => 27923,
        'Wykryte' =>     14937  ,
        '%_Wykrycia' =>  52.6
    ),
    'malopolskie' => array(
        'Stwierdzone' => 43978 ,
        'Wykryte' =>     29649  ,
        '%_Wykrycia' =>  67.0
    ),
    'kujawskopomorskie' => array(
        'Stwierdzone' => 22505 ,
        'Wykryte' =>     14306  ,
        '%_Wykrycia' =>  63.0
    ),
    'wielkopolskie' => array(
        'Stwierdzone' => 34616 ,
        'Wykryte' =>     21815  ,
        '%_Wykrycia' =>  62.6
    ),
);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //$_POST['id'] przekazaliśmy w właściwości data AJAX
    if (isset($_POST['id']) && array_key_exists($_POST['id'], $province)) {
        echo json_encode($province[$_POST['id']]);
    }
}
?>
